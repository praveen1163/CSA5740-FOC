#include<stdio.h>
#include<conio.h>
int main()
{
	int i,n;
	printf("Enter till: ");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		printf("%d\t",i);
	}
	return 0;
}
