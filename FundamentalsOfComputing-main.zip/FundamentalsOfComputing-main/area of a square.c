#include<stdio.h>
#include<conio.h>
int main()
{
	float area,side;
	printf("enter side:");
	scanf("%f",&side);
	area = side*side;
	printf("%.2f",area);
	return 0;
}
