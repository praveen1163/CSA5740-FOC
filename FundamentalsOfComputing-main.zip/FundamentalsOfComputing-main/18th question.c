//to check whether positive or negative
#include<stdio.h>
int main()
{
	int x;
	printf("Enter num: ");
	scanf("%d",&x);
	if(x>=0)
	{
		printf("The number is positive.");
	}
	else
	{
		printf("The number is negative.");
	}
	return 0;
}
