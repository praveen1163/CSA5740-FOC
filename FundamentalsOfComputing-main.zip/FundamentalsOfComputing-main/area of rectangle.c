#include<stdio.h>
#include<conio.h>
int main(){
	float length, breadth, area;
	printf("Enter length and breadth: ");
	scanf("%f %f",&length,&breadth);
	area = length*breadth;
	printf("%.2f",area);
	return 0;
}
