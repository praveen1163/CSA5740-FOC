//summing up odd number series upto n
#include<stdio.h>
int main()
{
	int x,k,sum=0;
	printf("Enter: ");
	scanf("%d",&x);
	for(k=1;k<=x;k++)
	{
		if(k%2!=0)
		{
			sum = sum+k;
		}
	}
	printf("%d",sum);
	return 0;
}
